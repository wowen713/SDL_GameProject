#ifndef game_h
#define game_h

#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>

#include <SDL2/SDL.h> 
#include <SDL2/SDL_image.h> 
#include <SDL2/SDL_timer.h>

using namespace std;

#endif
